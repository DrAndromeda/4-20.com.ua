tinyMCE.addI18n('ii.modxlink',{
    link_desc:"Insert/edit link"
});