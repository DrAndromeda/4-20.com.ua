tinyMCE.addI18n('tw.modxlink',{
    link_desc:"Insert/edit link"
});